package com.richard.calendar.dtos;

public record PropertyDTO(
    Long id,
    String name,
    String description
) {}
