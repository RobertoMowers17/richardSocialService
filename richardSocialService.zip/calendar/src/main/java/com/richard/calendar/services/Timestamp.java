package com.richard.calendar.services;

public class Timestamp {

}
