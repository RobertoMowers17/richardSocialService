package com.richard.calendar.dtos;

public record ProjectDTO(
    Long id,
    String name
) {}

