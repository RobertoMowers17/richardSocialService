import { Component } from '@angular/core';

@Component({
  selector: 'app-d-content',
  imports: [],
  templateUrl: './d-content.component.html',
  styleUrl: './d-content.component.css'
})
export class DContentComponent {

}
