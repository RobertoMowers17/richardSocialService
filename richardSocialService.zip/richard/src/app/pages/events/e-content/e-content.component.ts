import { Component } from '@angular/core';

@Component({
  selector: 'app-e-content',
  imports: [],
  templateUrl: './e-content.component.html',
  styleUrl: './e-content.component.css'
})
export class EContentComponent {

}
