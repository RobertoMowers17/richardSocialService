import { Component } from '@angular/core';

@Component({
  selector: 'app-form-content',
  imports: [],
  templateUrl: './form-content.component.html',
  styleUrl: './form-content.component.css'
})
export class FormContentComponent {

}
